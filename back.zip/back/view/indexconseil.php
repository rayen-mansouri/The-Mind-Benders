
<?php
include_once '../controller/conseilC.php';
include_once '../controller/commentaireC.php';


$s = new conseilC();
$commentaireC = new commentaireC();

//affichage
  $tab = $s->afficher();

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
  <title>AGRILINK</title>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


  <link rel="stylesheet" href="front\indexconseil.css">
  
</head>
<body>
  <header>
    <div class="container-fluid">
      <div class="row py-3 border-bottom">
        
        <div class="col-sm-4 col-lg-2 text-center text-sm-start d-flex gap-3 justify-content-center justify-content-md-start">
          <div class="d-flex align-items-center my-3 my-sm-0">
            <a href="index.html">
              <img src="front\images\logo.png" alt="logo" class="img-fluid">
            </a>
          </div>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar">
            <svg width="24" height="24" viewBox="0 0 24 24"><use xlink:href="#menu"></use></svg>
          </button>
        </div>
        
        <div class="col-sm-6 offset-sm-2 offset-md-0 col-lg-4">
          <div class="search-bar row bg-light p-2 rounded-4">
            
            <div class="col-11 col-md-7">
              <form id="search-form" class="text-center" action="index.html" method="post">
                <input type="text" class="form-control border-0 bg-transparent" placeholder="Search for more than 20,000 products">
              </form>
            </div>
            <div class="col-1">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M21.71 20.29L18 16.61A9 9 0 1 0 16.61 18l3.68 3.68a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.39ZM11 18a7 7 0 1 1 7-7a7 7 0 0 1-7 7Z"/></svg>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <ul class="navbar-nav list-unstyled d-flex flex-row gap-3 gap-lg-5 justify-content-center flex-wrap align-items-center mb-0 fw-bold text-uppercase text-dark">
            <li class="nav-item active">
              <a href="index.html" class="nav-link">Home</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle pe-3" role="button" id="pages" data-bs-toggle="dropdown" aria-expanded="false">Pages</a>
              <ul class="dropdown-menu border-0 p-3 rounded-0 shadow" aria-labelledby="pages">
                <li><a href="index.html" class="dropdown-item">About Us </a></li>
                <li><a href="index.html" class="dropdown-item">Shop </a></li>
                <li><a href="index.html" class="dropdown-item">Single Product </a></li>
                <li><a href="index.html" class="dropdown-item">Cart </a></li>
                <li><a href="index.html" class="dropdown-item">Checkout </a></li>
                <li><a href="blog.html" class="dropdown-item">Blog </a></li>
                <li><a href="index.html" class="dropdown-item">Single Post </a></li>
                <li><a href="index.html" class="dropdown-item">Styles </a></li>
                <li><a href="index.html" class="dropdown-item">Contact </a></li>
                <li><a href="index.html" class="dropdown-item">Thank You </a></li>
                <li><a href="index.html" class="dropdown-item">My Account </a></li>
                <li><a href="index.html" class="dropdown-item">404 Error </a></li>
              </ul>
            </li>
          </ul>
        </div>
        
        <div class="col-sm-8 col-lg-2 d-flex gap-5 align-items-center justify-content-center justify-content-sm-end">
          <ul class="d-flex justify-content-end list-unstyled m-0">
            <li>
              <a href="#" class="p-2 mx-1">
                <svg width="24" height="24"><use xlink:href="#user"></use></svg>
              </a>
            </li>
            <li>
              <a href="#" class="p-2 mx-1">
                <svg width="24" height="24"><use xlink:href="#wishlist"></use></svg>
              </a>
            </li>
            <li>
              <a href="#" class="p-2 mx-1" data-bs-toggle="offcanvas" data-bs-target="#offcanvasCart" aria-controls="offcanvasCart">
                <svg width="24" height="24"><use xlink:href="#shopping-bag"></use></svg>
              </a>
            </li>
          </ul>
        </div>

      </div>
    </div>
  </header>
  
  <section id="latest-blog" class="pb-4">
    <div class="container-lg">
      <div class="row">
        <div class="section-header d-flex align-items-center justify-content-between my-4">
          <h2 class="section-title">Our Recent Blog</h2>
          <a href="#" class="btn btn-primary">View All</a>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <article class="post-item card border-0 shadow-sm p-3">
            <div class="image-holder zoom-effect">
              <a href="#">
                <img src="front\images\samed1.png" alt="post" class="card-img-top">
              </a>
            </div>
            <div class="card-body">
              <div class="post-meta d-flex text-uppercase gap-3 my-2 align-items-center">
                <div class="meta-date"><svg width="16" height="16"><use xlink:href="#calendar"></use></svg>22 Aug 2021</div>
                <div class="meta-categories"><svg width="16" height="16"><use xlink:href="#category"></use></svg>tips & tricks</div>
              </div>
              <div class="post-header">
                <h3 class="post-title">
                  <a href="produit1.html?id=1" class="text-decoration-none">Terra Aquatica – HyperBloom Flowering fertilizer</a>
                </h3>
                <p>our best seller.</p>
              </div>
            </div>
          </article>
          <article class="post-item card border-0 shadow-sm p-3">
            <div class="image-holder zoom-effect">
              <a href="#">
                <img src="front\images\samed3.png" alt="post" class="card-img-top">
              </a>
            </div>
            <div class="card-body">
              <div class="post-meta d-flex text-uppercase gap-3 my-2 align-items-center">
                <div class="meta-date"><svg width="16" height="16"><use xlink:href="#calendar"></use></svg>22 Aug 2021</div>
                <div class="meta-categories"><svg width="16" height="16"><use xlink:href="#category"></use></svg>tips & tricks</div>
              </div>
              <div class="post-header">
                <h3 class="post-title">
                  <a href="#" class="text-decoration-none">Plagron Cocos Perlite 70/30</a>
                </h3>
                <p>our best seller.</p>
              </div>
            </div>
          </article>
          <article class="post-item card border-0 shadow-sm p-3">
            <div class="image-holder zoom-effect">
              <a href="#">
                <img src="front\images\samed4.png" alt="post" class="card-img-top">
              </a>
            </div>
            <div class="card-body">
              <div class="post-meta d-flex text-uppercase gap-3 my-2 align-items-center">
                <div class="meta-date"><svg width="16" height="16"><use xlink:href="#calendar"></use></svg>22 Aug 2021</div>
                <div class="meta-categories"><svg width="16" height="16"><use xlink:href="#category"></use></svg>tips & tricks</div>
              </div>
              <div class="post-header">
                <h3 class="post-title">
                  <a href="#" class="text-decoration-none">TERRA AQUATICA – ORGANIC SOIL LIGHT MIX 50L</a>
                </h3>
                <p>our best seller.</p>
              </div>
            </div>
          </article>
        </div>
        <div class="col-md-4">
          <article class="post-item card border-0 shadow-sm p-3">
            <div class="image-holder zoom-effect">
              <a href="#">
                <img src="front\images\samed2.png" alt="post" class="card-img-top">
              </a>
            </div>
            <div class="card-body">
              <div class="post-meta d-flex text-uppercase gap-3 my-2 align-items-center">
                <div class="meta-date"><svg width="16" height="16"><use xlink:href="#calendar"></use></svg>25 Aug 2021</div>
                <div class="meta-categories"><svg width="16" height="16"><use xlink:href="#category"></use></svg>trending</div>
              </div>
              <div class="post-header">
                <h3 class="post-title">
                  <a href="#" class="text-decoration-none">TERRA AQUATICA – ORGANIC SOIL LIGHT MIX 50L</a>
                </h3>
                <p>our best seller.</p>
              </div>
            </div>
          </article>
      </div>
        
         
              
              

      <h3 class="text-uppercase font-weight-bold wow-outer" style="margin-bottom: 30px;">
        <span class="wow slideInDown">Nos Conseils :</span>
    </h3>
    <div class="row row-lg-55 row-40 offset-top-3">
        <?php foreach ($tab as $conseil) { ?>
            <div class="col-md-6 wow-outer" style="margin-bottom: 20px;">
                <!-- Post Modern-->
                <article class="post-modern wow slideInLeft">
                    
                
                        
                           
                            <p style="font-size:15px;"> <?= $conseil['contenu'] ?></p>
                            <p style="font-size:15px;">Date Pub  : <?= $conseil['date_pub'] ?></p>
                  <!-- Comment Form -->
<form method="POST" action="ajoutCommentaire.php" onsubmit="return validateCommentForm();">
    <input type="hidden" name="id_con" value="<?= $conseil['id_con'] ?>">
    <textarea id="contenu" name="contenu" placeholder="Ajouter un commentaire" class="form-control mb-2" rows="3" required></textarea>
    
    <!-- Error message for validation -->
    <div id="error-message" style="color: red; display: none;">Le commentaire doit contenir au moins 10 caractères.</div>
    
    <button type="submit" class="btn btn-primary">Envoyer</button>
</form>

<script>
    function validateCommentForm() {
        // Get the 'contenu' field
        const contenuField = document.getElementById('contenu');
        
        // Get the value from the 'contenu' field and trim extra spaces
        const contenu = contenuField.value.trim();
        
        // Check if the content length is less than 10 characters
        if (contenu.length < 10) {
            // Show an alert with an error message
            alert("Le commentaire doit contenir au moins 10 caractères.");
            contenuField.focus(); // Focus on the 'contenu' field for user to edit
            return false; // Prevent form submission
        }
        
        // If everything is valid, allow form submission
        return true;
    }
</script>



                <!-- Display Comments -->
            <h5 class="mt-4">Commentaires :</h5>
            <div class="comment-section border rounded p-3">
                <?php 
                // Charger les commentaires pour le conseil actuel
                $commentaires = $commentaireC->afficherCommentaires($conseil['id_con']);

                if (!empty($commentaires)) {
                    foreach ($commentaires as $commentaire) { ?>
                        <div class="comment mb-3">
                            <p><strong>Date :</strong> <?= $commentaire['date_pub'] ?></p>
                            <p><?= $commentaire['contenu'] ?></p>
                            <hr>
                        </div>
                    <?php } 
                } else { ?>
                    <p class="text-muted">Aucun commentaire pour le moment.</p>
                <?php } ?>
            </div>
                
                    
                </article>
            </div>
        <?php } ?>
    </div>
          
          <footer class="py-4 bg-dark text-light">
            <div class="container-lg text-center">
              <img src="front\images\logo.png" width="160" alt="logo" class="mb-3">
              <div class="social-links mb-3">
                <a href="#" class="btn btn-outline-light btn-sm me-2"><svg width="16" height="16"><use xlink:href="#"></use></svg></a>
                <a href="#" class="btn btn-outline-light btn-sm me-2"><svg width="16" height="16"><use xlink:href="#"></use></svg></a>
                <a href="#" class="btn btn-outline-light btn-sm me-2"><svg width="16" height="16"><use xlink:href="#"></use></svg></a>
                <a href="#" class="btn btn-outline-light btn-sm me-2"><svg width="16" height="16"><use xlink:href="#"></use></svg></a>
                <a href="#" class="btn btn-outline-light btn-sm"><svg width="16" height="16"><use xlink:href="#"></use></svg></a>
              </div>
              <div class="footer-links">
                <a href="#" class="text-light me-3">facebook</a>
                <a href="#" class="text-light me-3">produit</a>
                <a href="#" class="text-light me-3">instagram</a>
                <a href="#" class="text-light">reclamation</a>
              </div>
              <p class="small mt-3 mb-0">© 2024 AgriLink. All rights reserved.</p>
            </div>
          </footer>
          <script> window.chtlConfig = { chatbotId: "2735997893" } </script>
<script async data-id="2735997893" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>
        
          



          
          
        
</body>
</html>