<?php
include_once '../config.php';
include_once '../model/cmn.php';

class commentaireC {
    // Fetch comments for a specific conseil
    public function afficherCommentaires($id_con)
    {
        $sql = "SELECT * FROM commentair WHERE id_con = :id_con ORDER BY date_pub DESC";
        $db = config::getConnexion();
        $query = $db->prepare($sql);
        $query->bindValue(':id_con', $id_con, PDO::PARAM_INT);
        $query->execute();
        return $query->fetchAll();
    }
    // Add a new comment
    public function ajouterCommentaire($id_con, $contenu) {
        $db = config::getConnexion();
        $query = $db->prepare("INSERT INTO commentair (id_con, contenu, date_pub) VALUES (:id_con, :contenu, NOW())");
        $query->execute(['id_con' => $id_con, 'contenu' => $contenu]);
    }
    
    public function afficherTousCommentaires() {
        try {
            $db = config::getConnexion();
            $sql = "SELECT * FROM commentair ORDER BY date_pub DESC";

            // Execute the query 
            $query = $db->query($sql);

            // Return all comments as an array
            return $query->fetchAll();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
        
    }
    public function supprimer($id_comnt) {
        try {
            $db = config::getConnexion();
            $sql = "DELETE FROM commentair WHERE id_cmnt = :id_cmnt";
            $query = $db->prepare($sql);
            $query->execute(['id_cmnt' => $id_comnt]);
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
    


  
    
}

?>
